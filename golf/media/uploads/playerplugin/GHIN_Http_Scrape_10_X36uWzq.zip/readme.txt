The archive must include context.json and 1 python module
context.json:
	name: is unique to each plugin and if you upload a duplicate a new version will be created
	priority: is used to sort the plugin list in club settings, -1 priority plugins are sorted only by name
	data: is sent to your plugin when it is run
	class_name: is the class within the module that will be used by Abstract Base Class
	description: helpful text for the users of the plugin